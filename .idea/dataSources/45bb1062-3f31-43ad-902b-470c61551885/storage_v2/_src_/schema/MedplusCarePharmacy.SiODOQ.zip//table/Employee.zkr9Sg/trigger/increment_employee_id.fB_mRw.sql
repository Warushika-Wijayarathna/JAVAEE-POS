create definer = root@localhost trigger increment_employee_id
    before insert
    on Employee
    for each row
BEGIN
    UPDATE AutoIncrement_Employee SET next_id = next_id + 1;
    SET NEW.emp_id = CONCAT('E', LPAD((SELECT next_id FROM AutoIncrement_Employee), 4, '0'));
END;


create definer = root@localhost trigger increment_prescription_id
    before insert
    on Prescription
    for each row
BEGIN
    UPDATE AutoIncrement_Prescription SET next_id = next_id + 1;
    SET NEW.presc_id = CONCAT('PR', LPAD((SELECT next_id FROM AutoIncrement_Prescription), 3, '0'));
END;


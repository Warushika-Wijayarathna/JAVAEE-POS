create definer = root@localhost trigger increment_order_id
    before insert
    on `Order`
    for each row
BEGIN
    UPDATE AutoIncrement_Order SET next_id = next_id + 1;
    SET NEW.o_id = CONCAT('O', LPAD((SELECT next_id FROM AutoIncrement_Order), 4, '0'));
END;


create definer = root@localhost trigger increment_supplier_id
    before insert
    on Supplier
    for each row
BEGIN
    UPDATE AutoIncrement_Supplier SET next_id = next_id + 1;
    SET NEW.sp_id = CONCAT('S', LPAD((SELECT next_id FROM AutoIncrement_Supplier), 4, '0'));
END;

